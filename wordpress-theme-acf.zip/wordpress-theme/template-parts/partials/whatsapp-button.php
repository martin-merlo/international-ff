<?php
/**
 * Botón flotante de WhatsApp.
 *
 * El anillo que late es CSS puro (animate-pulse-ring, definido en el CSS del
 * tema): no necesita JavaScript.
 *
 * @package International_FF
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$iff_contact = iff_contact();
?>
<a
	href="<?php echo esc_url( $iff_contact['whatsapp'] ); ?>"
	target="_blank"
	rel="noreferrer"
	aria-label="Escribinos por WhatsApp"
	class="fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-[oklch(0.68_0.17_148)] text-white shadow-[0_16px_36px_-12px_rgba(0,0,0,0.5)] animate-pulse-ring transition-transform hover:scale-105 sm:bottom-7 sm:right-7"
>
	<svg viewBox="0 0 24 24" class="h-7 w-7" fill="currentColor" aria-hidden="true">
		<path d="M17.47 14.38c-.29-.15-1.72-.85-1.99-.94-.27-.1-.46-.15-.66.15-.19.29-.75.94-.92 1.13-.17.19-.34.22-.63.07-.29-.15-1.23-.45-2.34-1.44-.87-.77-1.45-1.72-1.62-2.01-.17-.29-.02-.45.13-.6.13-.13.29-.34.44-.51.15-.17.19-.29.29-.48.1-.19.05-.36-.02-.51-.07-.15-.66-1.59-.9-2.18-.24-.57-.48-.49-.66-.5h-.56c-.19 0-.51.07-.77.36-.27.29-1.01.99-1.01 2.41s1.04 2.79 1.18 2.98c.15.19 2.04 3.11 4.94 4.36.69.3 1.23.48 1.65.61.69.22 1.32.19 1.82.12.56-.08 1.72-.7 1.96-1.38.24-.68.24-1.26.17-1.38-.07-.12-.26-.19-.55-.34z" />
		<path d="M12.04 2C6.6 2 2.17 6.43 2.17 11.87c0 1.74.46 3.44 1.32 4.94L2 22l5.35-1.4a9.85 9.85 0 0 0 4.69 1.2h.01c5.43 0 9.86-4.43 9.86-9.87C21.91 6.43 17.48 2 12.04 2zm0 17.98h-.01a8.2 8.2 0 0 1-4.17-1.14l-.3-.18-3.17.83.85-3.09-.2-.32a8.16 8.16 0 0 1-1.25-4.36c0-4.52 3.68-8.2 8.21-8.2a8.2 8.2 0 0 1 8.19 8.21c0 4.52-3.68 8.25-8.15 8.25z" />
	</svg>
</a>
